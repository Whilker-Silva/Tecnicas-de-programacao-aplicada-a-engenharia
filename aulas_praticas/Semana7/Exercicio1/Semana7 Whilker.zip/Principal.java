package aulas_praticas.Semana7.Exercicio1;

public class Principal {

    public static void main(String[] args) {

        Simulacao simulacao = new Simulacao(100, 3);
        
    }    
}
